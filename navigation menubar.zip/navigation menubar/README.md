# Navigation Menubar Project

A responsive portfolio-style landing page featuring a hexagonal navigation menu with hover effects, a full-screen background image, and modern icon-based section links.

## Overview

This project is a single-page HTML/CSS design inspired by a creative portfolio or personal website layout. It includes:

- Hexagon-shaped navigation items
- Hover animations and interactive transitions
- Full-page background hero section
- Bootstrap and Font Awesome icon integration
- Clean dark themed presentation

## Files

- [menus.html](menus.html) — main page structure and menu content
- [css/style.css](css/style.css) — custom styling for the layout and hover effects

## Features

- Modern hexagonal menu layout
- Responsive page design for different screen sizes
- Elegant dark overlay with background imagery
- Section titles such as Welcome, About, Services, Resume, Works, Testimonials, and Contact
- No backend or build setup required

## Getting Started

1. Download or open the project folder.
2. Open [menus.html](menus.html) in your browser.
3. If you want to preview it through a local server, run:


## Project Notes

- The page uses CDN-hosted CSS libraries, so an internet connection is required when loading the page for the first time.
- This is a static front-end project and does not require Node.js, npm, or any framework.

## License

This project is provided as a front-end demo/example for learning and personal use.
